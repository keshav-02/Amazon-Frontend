export class Category {
    id: number | undefined;
    catname: string | undefined;
}
